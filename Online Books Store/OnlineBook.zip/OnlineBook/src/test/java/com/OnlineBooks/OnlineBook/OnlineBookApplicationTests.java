package com.OnlineBooks.OnlineBook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineBookApplicationTests {

	@Test
	void contextLoads() {
	}

}
